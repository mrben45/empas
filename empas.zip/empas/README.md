## ⇨  Install Script Termux

$ pkg update && upgrade  

$ pkg install bash

$ pkg install git  

$ pkg install wget

$ pkg install pv
 
$ git clone https://github.com/users002/empas

$ cd empas

$ bash ml.sh


## ✭ ScreenShot
 <img src="https://github.com/users002/empas/blob/main/20210929_233025.png" width="640" title="ScreenShot" alt="Menu">
</p> 
